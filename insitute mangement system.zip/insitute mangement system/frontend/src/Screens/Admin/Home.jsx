/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Navbar from "../../components/Navbar";
import { toast, Toaster } from "react-hot-toast";
import axios from "axios";
import Notice from "../../components/Notice";
import Student from "./Student";
import Faculty from "./Faculty";
import Subjects from "./Subject";
import { baseApiURL } from "../../baseUrl";
import Admin from "./Admin";
import Profile from "./Profile";
import Branch from "./Branch";
import { 
  FaUser, 
  FaUsers, 
  FaChalkboardTeacher,
  FaUserShield,
  FaCodeBranch,
  FaBook
} from "react-icons/fa";

const Home = () => {
  const router = useLocation();
  const navigate = useNavigate();
  const [load, setLoad] = useState(false);
  const [selectedMenu, setSelectedMenu] = useState("My Profile");
  const [dashboardData, setDashboardData] = useState({
    studentCount: "",
    facultyCount: "",
  });
  useEffect(() => {
    if (router.state === null) {
      navigate("/");
    }
    setLoad(true);
  }, [navigate, router.state]);

  useEffect(() => {
    getStudentCount();
    getFacultyCount();
  }, []);

  const getStudentCount = () => {
    const headers = {
      "Content-Type": "application/json",
    };
    axios
      .get(`${baseApiURL()}/student/details/count`, {
        headers: headers,
      })
      .then((response) => {
        if (response.data.success) {
          setDashboardData({
            ...dashboardData,
            studentCount: response.data.user,
          });
        } else {
          toast.error(response.data.message);
        }
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const getFacultyCount = () => {
    const headers = {
      "Content-Type": "application/json",
    };
    axios
      .get(`${baseApiURL()}/faculty/details/count`, {
        headers: headers,
      })
      .then((response) => {
        if (response.data.success) {
          setDashboardData({
            ...dashboardData,
            facultyCount: response.data.user,
          });
        } else {
          toast.error(response.data.message);
        }
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const menuItems = [
    { id: "My Profile", icon: <FaUser className="w-5 h-5" /> },
    { id: "Students", icon: <FaUsers className="w-5 h-5" /> },
    { id: "Faculty", icon: <FaChalkboardTeacher className="w-5 h-5" /> },
    { id: "Admins", icon: <FaUserShield className="w-5 h-5" /> },
    { id: "Branches", icon: <FaCodeBranch className="w-5 h-5" /> },
    { id: "Subjects", icon: <FaBook className="w-5 h-5" /> },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {load && (
        <>
          <Navbar />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {/* Welcome Section */}
            <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
              <h1 className="text-2xl font-bold text-gray-800">Welcome Back, Administrator!</h1>
              <p className="text-gray-600 mt-2">Manage your institution's resources and users</p>
            </div>

            {/* Navigation Menu */}
            <div className="bg-white rounded-xl shadow-sm p-4 mb-8">
              <ul className="flex flex-wrap justify-center gap-4">
                {menuItems.map((item) => (
                  <li
                    key={item.id}
                    className={`flex items-center gap-2 px-6 py-3 rounded-lg cursor-pointer 
                      transition-all duration-300 transform hover:scale-105
                      ${selectedMenu === item.id
                        ? "bg-blue-600 text-white shadow-md"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    onClick={() => setSelectedMenu(item.id)}
                  >
                    {item.icon}
                    <span className="font-medium">{item.id}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Content Section */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="transition-all duration-300">
                {selectedMenu === "My Profile" && <Profile />}
                {selectedMenu === "Students" && <Student />}
                {selectedMenu === "Faculty" && <Faculty />}
                {selectedMenu === "Admins" && <Admin />}
                {selectedMenu === "Branches" && <Branch />}
                {selectedMenu === "Subjects" && <Subjects />}
              </div>
            </div>
          </div>
        </>
      )}
      <Toaster position="bottom-center" />
    </div>
  );
};

export default Home;
