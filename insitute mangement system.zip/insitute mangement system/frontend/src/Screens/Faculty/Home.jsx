import React, { useEffect, useState } from "react";
import Navbar from "../../components/Navbar";
import Profile from "./Profile";
import Timetable from "./Timetable";
import Marks from "./Marks";
import Notice from "../../components/Notice";
import Material from "./Material";
import Student from "./Student";
import { Toaster } from "react-hot-toast";
import { useLocation, useNavigate } from "react-router-dom";
import { 
  FaUser, 
  FaCalendarAlt, 
  FaGraduationCap, 
  FaBook, 
  FaBell,
  FaUsers
} from "react-icons/fa";

const Home = () => {
  const [selectedMenu, setSelectedMenu] = useState("My Profile");
  const router = useLocation();
  const navigate = useNavigate();
  const [load, setLoad] = useState(false);

  useEffect(() => {
    if (router.state === null) {
      navigate("/");
    }
    setLoad(true);
  }, [navigate, router.state]);

  const menuItems = [
    { id: "My Profile", icon: <FaUser className="w-5 h-5" /> },
    { id: "Timetable", icon: <FaCalendarAlt className="w-5 h-5" /> },
    { id: "Marks", icon: <FaGraduationCap className="w-5 h-5" /> },
    { id: "Material", icon: <FaBook className="w-5 h-5" /> },
    { id: "Notice", icon: <FaBell className="w-5 h-5" /> },
    { id: "Students", icon: <FaUsers className="w-5 h-5" /> },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {load && (
        <>
          <Navbar />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {/* Welcome Section */}
            <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
              <h1 className="text-2xl font-bold text-gray-800">Welcome Back, Professor!</h1>
              <p className="text-gray-600 mt-2">Manage your classes and students efficiently</p>
            </div>

            {/* Navigation Menu */}
            <div className="bg-white rounded-xl shadow-sm p-4 mb-8">
              <ul className="flex flex-wrap justify-center gap-4">
                {menuItems.map((item) => (
                  <li
                    key={item.id}
                    className={`flex items-center gap-2 px-6 py-3 rounded-lg cursor-pointer 
                      transition-all duration-300 transform hover:scale-105
                      ${selectedMenu === item.id
                        ? "bg-blue-600 text-white shadow-md"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    onClick={() => setSelectedMenu(item.id)}
                  >
                    {item.icon}
                    <span className="font-medium">{item.id}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Content Section */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="transition-all duration-300">
                {selectedMenu === "Timetable" && <Timetable />}
                {selectedMenu === "Marks" && <Marks />}
                {selectedMenu === "Material" && <Material />}
                {selectedMenu === "Notice" && <Notice />}
                {selectedMenu === "My Profile" && <Profile />}
                {selectedMenu === "Students" && <Student />}
              </div>
            </div>
          </div>
        </>
      )}
      <Toaster position="bottom-center" />
    </div>
  );
};

export default Home;
