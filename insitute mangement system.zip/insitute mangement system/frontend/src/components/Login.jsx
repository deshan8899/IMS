import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { FiLogIn } from "react-icons/fi";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";
import { baseApiURL } from "../baseUrl";

const Login = () => {
  const navigate = useNavigate();
  const [selected, setSelected] = useState("Student");
  const { register, handleSubmit } = useForm();
  
  const onSubmit = (data) => {
    if (data.loginid !== "" && data.password !== "") {
      const headers = {
        "Content-Type": "application/json",
      };
      const url = `${baseApiURL()}/${selected.toLowerCase()}/auth/login`; 

      console.log("Login URL:", url);

      axios
        .post(url, data, { headers: headers })
        .then((response) => {
          navigate(`/${selected.toLowerCase()}`, {
            state: { type: selected, loginid: response.data.loginid },
          });
        })
        .catch((error) => {
          toast.dismiss();
          console.error(error);
          toast.error(error.response?.data?.message || "An error occurred");
        });
    } else {
      toast.error("Please fill in all fields");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl bg-white rounded-2xl shadow-xl overflow-hidden flex">
        {/* Left side - Logo and Welcome */}
        <div className="hidden md:flex w-1/2 bg-gradient-to-br from-blue-600 to-indigo-600 p-12 flex-col justify-center items-center text-white">
          <img src="./logo.svg" alt="Logo" className="w-48 mb-8" />
          <h1 className="text-4xl font-bold mb-4">Welcome Back!</h1>
          <p className="text-blue-100 text-center">
            Access your learning management system with ease
          </p>
        </div>

        {/* Right side - Login Form */}
        <div className="w-full md:w-1/2 p-8 md:p-12">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold text-gray-800">
              {selected} Login
            </h2>
            <div className="flex gap-4">
              {["Student", "Faculty", "Admin"].map((role) => (
                <button
                  key={role}
                  className={`text-sm font-medium transition-all duration-300 ${
                    selected === role
                      ? "text-blue-600 border-b-2 border-blue-600"
                      : "text-gray-500 hover:text-blue-600"
                  }`}
                  onClick={() => setSelected(role)}
                >
                  {role}
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <label className="label" htmlFor="loginid">
                {selected} Login ID
              </label>
              <input
                type="number"
                id="loginid"
                required
                className="input-field"
                placeholder="Enter your login ID"
                {...register("loginid")}
              />
            </div>

            <div>
              <label className="label" htmlFor="password">
                Password
              </label>
              <input
                type="password"
                id="password"
                required
                className="input-field"
                placeholder="Enter your password"
                {...register("password")}
              />
            </div>

            <button type="submit" className="btn-primary w-full">
              <span>Login</span>
              <FiLogIn className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
      <Toaster position="bottom-center" />
    </div>
  );
};

export default Login;
