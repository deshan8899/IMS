import React from "react";
import { FiLogOut } from "react-icons/fi";
import { useLocation, useNavigate } from "react-router-dom";
import { RxDashboard } from "react-icons/rx";
import { FaUserCircle } from "react-icons/fa";

const Navbar = () => {
  const router = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    // Add any logout logic here
    navigate("/");
  };

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Left side - Logo and Title */}
          <div className="flex items-center">
            <div 
              className="flex items-center cursor-pointer group"
              onClick={() => navigate("/")}
            >
              <div className="p-2 rounded-lg bg-blue-600 text-white group-hover:bg-blue-700 transition-colors duration-200">
                <RxDashboard className="w-6 h-6" />
              </div>
              <div className="ml-3">
                <h1 className="text-xl font-bold text-gray-800">
                  {router.state && router.state.type} Dashboard
                </h1>
                <p className="text-sm text-gray-500">Learning Management System</p>
              </div>
            </div>
          </div>

          {/* Right side - User Info and Logout */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center text-gray-700">
              <FaUserCircle className="w-6 h-6 mr-2" />
              <span className="text-sm font-medium">
                {router.state && router.state.loginid}
              </span>
            </div>
            <button
              className="flex items-center px-4 py-2 text-sm font-medium text-red-600 
                       bg-red-50 rounded-lg hover:bg-red-100 transition-colors duration-200"
              onClick={handleLogout}
            >
              <FiLogOut className="w-4 h-4 mr-2" />
              Logout
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
