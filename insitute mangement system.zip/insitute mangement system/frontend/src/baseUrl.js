// // baseUrl.js
export const baseApiURL = () => {
  return process.env.REACT_APP_APILINK; // This will return the value of REACT_APP_APILINK from .env
};
